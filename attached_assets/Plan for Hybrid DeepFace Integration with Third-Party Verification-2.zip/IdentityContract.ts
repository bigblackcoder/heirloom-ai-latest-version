import { ethers } from 'ethers';

// Define window.ethereum for TypeScript
declare global {
  interface Window {
    ethereum: any;
  }
}

// ABI for the Identity Verification Smart Contract
const IdentityContractABI = [
  // Events
  "event IdentityVerified(address indexed user, string verificationMethod, uint256 timestamp)",
  "event AccessGranted(address indexed user, address indexed to, uint256 timestamp, uint256 expirationTime)",
  "event AccessRevoked(address indexed user, address indexed from, uint256 timestamp)",
  
  // Functions
  "function verifyIdentity(string memory method) public returns (bool)",
  "function getVerificationHistory(address user) public view returns (string[] memory methods, uint256[] memory timestamps)",
  "function grantAccess(address to, uint256 expirationTime) public returns (bool)",
  "function revokeAccess(address from) public returns (bool)",
  "function checkAccess(address user, address accessor) public view returns (bool hasAccess, uint256 expirationTime)"
];

// Contract address on Polygon Testnet (Mumbai)
const CONTRACT_ADDRESS = "0x0000000000000000000000000000000000000000"; // Replace with actual deployed contract

export class IdentityContractService {
  private provider: ethers.providers.Web3Provider | null = null;
  private signer: ethers.Signer | null = null;
  private contract: ethers.Contract | null = null;
  private isConnected: boolean = false;

  constructor() {
    this.initializeProvider();
  }

  /**
   * Initialize the Web3 provider and connect to Polygon Testnet
   */
  async initializeProvider(): Promise<boolean> {
    try {
      // Check if MetaMask or other Web3 provider is available
      if (window.ethereum) {
        // Create a Web3Provider instance
        this.provider = new ethers.providers.Web3Provider(window.ethereum);
        
        // Request account access if needed
        await window.ethereum.request({ method: 'eth_requestAccounts' });
        
        // Get the signer
        this.signer = this.provider.getSigner();
        
        // Create contract instance
        this.contract = new ethers.Contract(
          CONTRACT_ADDRESS,
          IdentityContractABI,
          this.signer
        );
        
        // Check if we're connected to Polygon Testnet (Mumbai)
        const network = await this.provider.getNetwork();
        this.isConnected = network.chainId === 80001; // Mumbai Testnet Chain ID
        
        if (!this.isConnected) {
          console.warn("Not connected to Polygon Mumbai Testnet. Attempting to switch network...");
          await this.switchToPolygonTestnet();
        }
        
        return this.isConnected;
      } else {
        console.error("No Ethereum provider found. Please install MetaMask or another Web3 wallet.");
        return false;
      }
    } catch (error) {
      console.error("Error initializing Web3 provider:", error);
      return false;
    }
  }
  
  /**
   * Switch to Polygon Testnet (Mumbai)
   */
  async switchToPolygonTestnet(): Promise<boolean> {
    try {
      if (!window.ethereum) return false;
      
      try {
        // Try to switch to Polygon Mumbai Testnet
        await window.ethereum.request({
          method: 'wallet_switchEthereumChain',
          params: [{ chainId: '0x13881' }], // 80001 in hex
        });
        return true;
      } catch (switchError: any) {
        // If the network is not added, add it
        if (switchError.code === 4902) {
          await window.ethereum.request({
            method: 'wallet_addEthereumChain',
            params: [
              {
                chainId: '0x13881',
                chainName: 'Polygon Mumbai Testnet',
                nativeCurrency: {
                  name: 'MATIC',
                  symbol: 'MATIC',
                  decimals: 18,
                },
                rpcUrls: ['https://rpc-mumbai.maticvigil.com/'],
                blockExplorerUrls: ['https://mumbai.polygonscan.com/'],
              },
            ],
          });
          return true;
        }
        throw switchError;
      }
    } catch (error) {
      console.error("Error switching to Polygon Testnet:", error);
      return false;
    }
  }
  
  /**
   * Store identity verification on the blockchain
   * @param method The verification method used (e.g., "face", "fingerprint", "password")
   * @returns Transaction hash if successful
   */
  async storeVerification(method: string): Promise<string | null> {
    try {
      if (!this.isConnected || !this.contract) {
        const connected = await this.initializeProvider();
        if (!connected) return null;
      }
      
      // Call the smart contract function
      const tx = await this.contract!.verifyIdentity(method);
      
      // Wait for transaction to be mined
      const receipt = await tx.wait();
      
      console.log("Identity verification stored on blockchain:", receipt.transactionHash);
      return receipt.transactionHash;
    } catch (error) {
      console.error("Error storing verification on blockchain:", error);
      return null;
    }
  }
  
  /**
   * Get verification history for a user
   * @param userAddress Ethereum address of the user
   * @returns Array of verification methods and timestamps
   */
  async getVerificationHistory(userAddress?: string): Promise<{methods: string[], timestamps: number[]} | null> {
    try {
      if (!this.isConnected || !this.contract) {
        const connected = await this.initializeProvider();
        if (!connected) return null;
      }
      
      // If no address provided, use the current user's address
      if (!userAddress) {
        userAddress = await this.signer!.getAddress();
      }
      
      // Call the smart contract function
      const history = await this.contract!.getVerificationHistory(userAddress);
      
      return {
        methods: history.methods,
        timestamps: history.timestamps.map((t: ethers.BigNumber) => t.toNumber())
      };
    } catch (error) {
      console.error("Error getting verification history:", error);
      return null;
    }
  }
  
  /**
   * Grant access to another address
   * @param toAddress Address to grant access to
   * @param expirationTime Unix timestamp when access expires (0 for no expiration)
   * @returns Transaction hash if successful
   */
  async grantAccess(toAddress: string, expirationTime: number = 0): Promise<string | null> {
    try {
      if (!this.isConnected || !this.contract) {
        const connected = await this.initializeProvider();
        if (!connected) return null;
      }
      
      // Call the smart contract function
      const tx = await this.contract!.grantAccess(toAddress, expirationTime);
      
      // Wait for transaction to be mined
      const receipt = await tx.wait();
      
      console.log("Access granted on blockchain:", receipt.transactionHash);
      return receipt.transactionHash;
    } catch (error) {
      console.error("Error granting access on blockchain:", error);
      return null;
    }
  }
  
  /**
   * Revoke access from an address
   * @param fromAddress Address to revoke access from
   * @returns Transaction hash if successful
   */
  async revokeAccess(fromAddress: string): Promise<string | null> {
    try {
      if (!this.isConnected || !this.contract) {
        const connected = await this.initializeProvider();
        if (!connected) return null;
      }
      
      // Call the smart contract function
      const tx = await this.contract!.revokeAccess(fromAddress);
      
      // Wait for transaction to be mined
      const receipt = await tx.wait();
      
      console.log("Access revoked on blockchain:", receipt.transactionHash);
      return receipt.transactionHash;
    } catch (error) {
      console.error("Error revoking access on blockchain:", error);
      return null;
    }
  }
  
  /**
   * Check if an address has access to the user's data
   * @param userAddress User's address
   * @param accessorAddress Address to check access for
   * @returns Object with hasAccess boolean and expirationTime
   */
  async checkAccess(userAddress: string, accessorAddress: string): Promise<{hasAccess: boolean, expirationTime: number} | null> {
    try {
      if (!this.isConnected || !this.contract) {
        const connected = await this.initializeProvider();
        if (!connected) return null;
      }
      
      // Call the smart contract function
      const result = await this.contract!.checkAccess(userAddress, accessorAddress);
      
      return {
        hasAccess: result.hasAccess,
        expirationTime: result.expirationTime.toNumber()
      };
    } catch (error) {
      console.error("Error checking access on blockchain:", error);
      return null;
    }
  }
  
  /**
   * Get the current user's Ethereum address
   * @returns User's Ethereum address
   */
  async getUserAddress(): Promise<string | null> {
    try {
      if (!this.signer) {
        const connected = await this.initializeProvider();
        if (!connected) return null;
      }
      
      return await this.signer!.getAddress();
    } catch (error) {
      console.error("Error getting user address:", error);
      return null;
    }
  }
}

// Export singleton instance
export const identityContractService = new IdentityContractService();
