import React, { useState, useEffect } from 'react';
import '../styles/BlockchainOnboarding.css';

interface BlockchainOnboardingProps {
  onComplete: () => void;
  onSkip: () => void;
}

const BlockchainOnboarding: React.FC<BlockchainOnboardingProps> = ({ onComplete, onSkip }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [hasMetaMask, setHasMetaMask] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [isCorrectNetwork, setIsCorrectNetwork] = useState(false);
  const [walletAddress, setWalletAddress] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  // Check for MetaMask on component mount
  useEffect(() => {
    checkForMetaMask();
  }, []);

  // Check if MetaMask is installed
  const checkForMetaMask = () => {
    if (window.ethereum) {
      setHasMetaMask(true);
      checkConnection();
    } else {
      setHasMetaMask(false);
    }
  };

  // Check if already connected to MetaMask
  const checkConnection = async () => {
    try {
      const accounts = await window.ethereum.request({ method: 'eth_accounts' });
      if (accounts.length > 0) {
        setIsConnected(true);
        setWalletAddress(accounts[0]);
        checkNetwork();
      } else {
        setIsConnected(false);
      }
    } catch (error) {
      console.error('Error checking connection:', error);
      setErrorMessage('Failed to check wallet connection. Please refresh and try again.');
    }
  };

  // Check if connected to Polygon Mumbai Testnet
  const checkNetwork = async () => {
    try {
      const chainId = await window.ethereum.request({ method: 'eth_chainId' });
      setIsCorrectNetwork(chainId === '0x13881'); // Mumbai Testnet Chain ID (80001 in hex)
    } catch (error) {
      console.error('Error checking network:', error);
      setErrorMessage('Failed to check network. Please refresh and try again.');
    }
  };

  // Connect to MetaMask
  const connectWallet = async () => {
    try {
      const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
      setIsConnected(true);
      setWalletAddress(accounts[0]);
      setCurrentStep(3);
      checkNetwork();
    } catch (error) {
      console.error('Error connecting to wallet:', error);
      setErrorMessage('Failed to connect wallet. Please try again or check if MetaMask is unlocked.');
    }
  };

  // Switch to Polygon Mumbai Testnet
  const switchToMumbai = async () => {
    try {
      await window.ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: '0x13881' }], // Mumbai Testnet Chain ID (80001 in hex)
      });
      setIsCorrectNetwork(true);
      setCurrentStep(4);
    } catch (switchError: any) {
      // This error code indicates that the chain has not been added to MetaMask
      if (switchError.code === 4902) {
        try {
          await window.ethereum.request({
            method: 'wallet_addEthereumChain',
            params: [
              {
                chainId: '0x13881',
                chainName: 'Polygon Mumbai Testnet',
                nativeCurrency: {
                  name: 'MATIC',
                  symbol: 'MATIC',
                  decimals: 18,
                },
                rpcUrls: ['https://rpc-mumbai.maticvigil.com/'],
                blockExplorerUrls: ['https://mumbai.polygonscan.com/'],
              },
            ],
          });
          setIsCorrectNetwork(true);
          setCurrentStep(4);
        } catch (addError) {
          console.error('Error adding Mumbai network:', addError);
          setErrorMessage('Failed to add Mumbai network. Please try adding it manually in MetaMask.');
        }
      } else {
        console.error('Error switching network:', switchError);
        setErrorMessage('Failed to switch network. Please try switching manually in MetaMask.');
      }
    }
  };

  // Get test MATIC tokens
  const getTestMatic = () => {
    window.open('https://faucet.polygon.technology/', '_blank');
    setCurrentStep(5);
  };

  // Complete onboarding
  const completeOnboarding = () => {
    onComplete();
  };

  // Skip onboarding and use simulation mode
  const skipOnboarding = () => {
    onSkip();
  };

  // Render step content based on current step
  const renderStepContent = () => {
    switch (currentStep) {
      case 1: // Check for MetaMask
        return (
          <div className="onboarding-step">
            <h3>Step 1: MetaMask Wallet</h3>
            {hasMetaMask ? (
              <div className="step-content">
                <div className="success-message">
                  <span className="check-icon">✓</span>
                  MetaMask detected!
                </div>
                <button className="primary-button" onClick={() => setCurrentStep(2)}>
                  Continue
                </button>
              </div>
            ) : (
              <div className="step-content">
                <p>MetaMask is required to connect to the blockchain.</p>
                <a
                  href="https://metamask.io/download/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="primary-button"
                >
                  Install MetaMask
                </a>
                <p className="note">After installing, please refresh this page.</p>
                <button className="secondary-button" onClick={skipOnboarding}>
                  Continue in Simulation Mode
                </button>
              </div>
            )}
          </div>
        );

      case 2: // Connect to MetaMask
        return (
          <div className="onboarding-step">
            <h3>Step 2: Connect Wallet</h3>
            {isConnected ? (
              <div className="step-content">
                <div className="success-message">
                  <span className="check-icon">✓</span>
                  Wallet connected!
                </div>
                <p className="wallet-address">
                  {walletAddress.substring(0, 6)}...{walletAddress.substring(walletAddress.length - 4)}
                </p>
                <button className="primary-button" onClick={() => setCurrentStep(3)}>
                  Continue
                </button>
              </div>
            ) : (
              <div className="step-content">
                <p>Connect your MetaMask wallet to continue.</p>
                <button className="primary-button" onClick={connectWallet}>
                  Connect Wallet
                </button>
                <button className="secondary-button" onClick={skipOnboarding}>
                  Continue in Simulation Mode
                </button>
              </div>
            )}
          </div>
        );

      case 3: // Switch to Mumbai Testnet
        return (
          <div className="onboarding-step">
            <h3>Step 3: Switch to Polygon Mumbai Testnet</h3>
            {isCorrectNetwork ? (
              <div className="step-content">
                <div className="success-message">
                  <span className="check-icon">✓</span>
                  Connected to Polygon Mumbai Testnet!
                </div>
                <button className="primary-button" onClick={() => setCurrentStep(4)}>
                  Continue
                </button>
              </div>
            ) : (
              <div className="step-content">
                <p>Switch to the Polygon Mumbai Testnet to continue.</p>
                <button className="primary-button" onClick={switchToMumbai}>
                  Switch Network
                </button>
                <div className="network-details">
                  <h4>Network Details:</h4>
                  <ul>
                    <li>Network Name: Polygon Mumbai Testnet</li>
                    <li>RPC URL: https://rpc-mumbai.maticvigil.com/</li>
                    <li>Chain ID: 80001</li>
                    <li>Currency Symbol: MATIC</li>
                    <li>Block Explorer: https://mumbai.polygonscan.com/</li>
                  </ul>
                </div>
                <button className="secondary-button" onClick={skipOnboarding}>
                  Continue in Simulation Mode
                </button>
              </div>
            )}
          </div>
        );

      case 4: // Get test MATIC
        return (
          <div className="onboarding-step">
            <h3>Step 4: Get Test MATIC Tokens</h3>
            <div className="step-content">
              <p>You'll need test MATIC tokens to perform transactions on the testnet.</p>
              <button className="primary-button" onClick={getTestMatic}>
                Get Test MATIC
              </button>
              <p className="note">
                This will open the Polygon Faucet in a new tab. Request tokens using your wallet address.
              </p>
              <button className="secondary-button" onClick={() => setCurrentStep(5)}>
                I Already Have Test MATIC
              </button>
            </div>
          </div>
        );

      case 5: // Complete
        return (
          <div className="onboarding-step">
            <h3>Setup Complete!</h3>
            <div className="step-content">
              <div className="success-message">
                <span className="check-icon">✓</span>
                Your wallet is now connected to Polygon Mumbai Testnet
              </div>
              <p>You're ready to use the blockchain features of this application.</p>
              <button className="primary-button" onClick={completeOnboarding}>
                Start Using the App
              </button>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="blockchain-onboarding">
      <div className="onboarding-header">
        <h2>Blockchain Connection Setup</h2>
        <p>Follow these steps to connect to the Polygon blockchain for identity verification.</p>
      </div>

      <div className="onboarding-progress">
        <div className="progress-steps">
          {[1, 2, 3, 4, 5].map((step) => (
            <div
              key={step}
              className={`progress-step ${currentStep >= step ? 'active' : ''} ${
                currentStep > step ? 'completed' : ''
              }`}
            >
              {currentStep > step ? '✓' : step}
            </div>
          ))}
        </div>
        <div className="progress-labels">
          <span>MetaMask</span>
          <span>Connect</span>
          <span>Network</span>
          <span>Tokens</span>
          <span>Complete</span>
        </div>
      </div>

      {errorMessage && <div className="error-message">{errorMessage}</div>}

      {renderStepContent()}

      <div className="onboarding-footer">
        <button className="text-button" onClick={skipOnboarding}>
          Skip and use simulation mode
        </button>
      </div>
    </div>
  );
};

export default BlockchainOnboarding;
