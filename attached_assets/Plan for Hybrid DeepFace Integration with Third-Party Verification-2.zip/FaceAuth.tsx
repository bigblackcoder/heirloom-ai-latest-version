import React, { useState, useRef, useEffect } from 'react';
import Webcam from 'react-webcam';
import * as faceapi from 'face-api.js';
import '../styles/FaceAuth.css';

// Mock biometric interfaces for web/mobile compatibility
interface BiometricInterface {
  isSensorAvailable: () => Promise<boolean>;
  authenticate: (promptMessage: string) => Promise<boolean>;
}

// Apple FaceID mock implementation
const AppleFaceID: BiometricInterface = {
  isSensorAvailable: async () => {
    // Check if running on iOS device with FaceID
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
    return isIOS && 'FaceID' in window;
  },
  authenticate: async (promptMessage: string) => {
    console.log('Authenticating with Apple FaceID:', promptMessage);
    // In a real implementation, this would use the Web Authentication API
    return new Promise((resolve) => {
      setTimeout(() => resolve(true), 2000);
    });
  }
};

// Google Biometric mock implementation
const GoogleBiometric: BiometricInterface = {
  isSensorAvailable: async () => {
    // Check if running on Android device with biometric capability
    const isAndroid = /Android/.test(navigator.userAgent);
    return isAndroid && 'credentials' in navigator;
  },
  authenticate: async (promptMessage: string) => {
    console.log('Authenticating with Google Biometric:', promptMessage);
    // In a real implementation, this would use the Credential Management API
    return new Promise((resolve) => {
      setTimeout(() => resolve(true), 2000);
    });
  }
};

// Fingerprint authentication mock
const FingerprintAuth: BiometricInterface = {
  isSensorAvailable: async () => {
    // Check if fingerprint API is available
    return 'PublicKeyCredential' in window;
  },
  authenticate: async (promptMessage: string) => {
    console.log('Authenticating with Fingerprint:', promptMessage);
    // In a real implementation, this would use the Web Authentication API
    return new Promise((resolve) => {
      setTimeout(() => resolve(true), 2000);
    });
  }
};

interface FaceAuthProps {
  onAuthSuccess: (userId: string) => void;
  onAuthFailure: (error: string) => void;
}

const FaceAuth: React.FC<FaceAuthProps> = ({ onAuthSuccess, onAuthFailure }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [scanProgress, setScanProgress] = useState(0);
  const [authMethod, setAuthMethod] = useState<'face' | 'fingerprint' | 'password'>('face');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('Initializing facial recognition...');
  const [isVerified, setIsVerified] = useState(false);
  const [availableBiometrics, setAvailableBiometrics] = useState<string[]>([]);
  
  const webcamRef = useRef<Webcam>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const intervalRef = useRef<number | null>(null);

  // Load face-api models
  useEffect(() => {
    const loadModels = async () => {
      try {
        setMessage('Loading facial recognition models...');
        
        // Load models from public directory
        await faceapi.nets.tinyFaceDetector.loadFromUri('/models');
        await faceapi.nets.faceLandmark68Net.loadFromUri('/models');
        await faceapi.nets.faceRecognitionNet.loadFromUri('/models');
        
        setMessage('Models loaded successfully');
        setIsLoading(false);
        
        // Check available biometric methods
        checkAvailableBiometrics();
      } catch (error) {
        console.error('Error loading models:', error);
        setMessage('Error loading facial recognition models');
        onAuthFailure('Failed to load facial recognition models');
      }
    };
    
    loadModels();
    
    // Clean up on unmount
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [onAuthFailure]);
  
  // Check which biometric methods are available
  const checkAvailableBiometrics = async () => {
    const biometrics = [];
    
    if (await AppleFaceID.isSensorAvailable()) {
      biometrics.push('applefaceid');
    }
    
    if (await GoogleBiometric.isSensorAvailable()) {
      biometrics.push('googlebiometric');
    }
    
    if (await FingerprintAuth.isSensorAvailable()) {
      biometrics.push('fingerprint');
    }
    
    setAvailableBiometrics(biometrics);
  };
  
  // Start facial scanning process
  const startFacialScan = () => {
    if (!webcamRef.current || !canvasRef.current) return;
    
    setMessage('Position your face in the circle');
    setScanProgress(0);
    
    // Simulate progressive scanning
    let progress = 0;
    intervalRef.current = window.setInterval(() => {
      progress += 5;
      setScanProgress(progress);
      
      if (progress >= 100) {
        if (intervalRef.current) clearInterval(intervalRef.current);
        completeFacialScan();
      }
    }, 200);
  };
  
  // Complete the facial scan and verify identity
  const completeFacialScan = async () => {
    setMessage('Verifying identity...');
    
    try {
      // In a real implementation, this would use deepface for verification
      // For demo purposes, we'll simulate a successful verification
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Store verification on blockchain (will be implemented in next step)
      await storeVerificationOnBlockchain();
      
      setIsVerified(true);
      setMessage('Identity verified successfully');
      onAuthSuccess('user123'); // Pass user ID to parent component
    } catch (error) {
      console.error('Verification failed:', error);
      setMessage('Verification failed. Please try again.');
      onAuthFailure('Facial verification failed');
    }
  };
  
  // Authenticate with fingerprint
  const authenticateWithFingerprint = async () => {
    setMessage('Scanning fingerprint...');
    
    try {
      const isAuthenticated = await FingerprintAuth.authenticate('Verify your identity with fingerprint');
      
      if (isAuthenticated) {
        await storeVerificationOnBlockchain();
        setIsVerified(true);
        setMessage('Fingerprint verified successfully');
        onAuthSuccess('user123');
      } else {
        setMessage('Fingerprint verification failed');
        onAuthFailure('Fingerprint verification failed');
      }
    } catch (error) {
      console.error('Fingerprint authentication error:', error);
      setMessage('Fingerprint authentication error');
      onAuthFailure('Fingerprint authentication error');
    }
  };
  
  // Authenticate with username/password
  const authenticateWithPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setMessage('Verifying credentials...');
    
    try {
      // In a real implementation, this would validate against a secure backend
      // For demo purposes, we'll accept any non-empty username/password
      if (username.trim() && password.trim()) {
        await storeVerificationOnBlockchain();
        setIsVerified(true);
        setMessage('Credentials verified successfully');
        onAuthSuccess('user123');
      } else {
        setMessage('Invalid username or password');
        onAuthFailure('Invalid credentials');
      }
    } catch (error) {
      console.error('Password authentication error:', error);
      setMessage('Authentication error');
      onAuthFailure('Password authentication error');
    }
  };
  
  // Store verification on Polygon blockchain (placeholder for next implementation step)
  const storeVerificationOnBlockchain = async () => {
    try {
      // This will be implemented in the next step
      console.log('Storing verification on Polygon blockchain...');
      
      // Simulate blockchain transaction
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      console.log('Verification stored on blockchain successfully');
      return true;
    } catch (error) {
      console.error('Blockchain storage error:', error);
      return false;
    }
  };
  
  // Switch authentication method
  const switchAuthMethod = (method: 'face' | 'fingerprint' | 'password') => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    
    setAuthMethod(method);
    setScanProgress(0);
    setMessage(method === 'face' ? 'Position your face in the circle' : 
               method === 'fingerprint' ? 'Ready for fingerprint scan' : 
               'Enter your credentials');
  };
  
  // Render facial authentication UI
  const renderFaceAuth = () => (
    <div className="face-auth-container">
      <div className="webcam-container">
        <div className="scan-overlay" style={{ backgroundImage: `conic-gradient(#4CAF50 ${scanProgress * 3.6}deg, transparent 0deg)` }}>
          <div className="scan-circle">
            <Webcam
              audio={false}
              ref={webcamRef}
              screenshotFormat="image/jpeg"
              videoConstraints={{
                facingMode: "user"
              }}
              className="webcam"
            />
            <div className="scan-crosshair">
              <div className="crosshair-h"></div>
              <div className="crosshair-v"></div>
            </div>
          </div>
        </div>
        <canvas ref={canvasRef} className="face-canvas" />
      </div>
      
      <div className="scan-progress">
        <span className="progress-percentage">{scanProgress}%</span>
        <p className="scan-instruction">Move your head slowly to complete the circle.</p>
      </div>
      
      <div className="progress-bar-container">
        <div className="progress-bar" style={{ width: `${scanProgress}%` }}></div>
      </div>
      
      {scanProgress === 0 && (
        <button className="start-scan-btn" onClick={startFacialScan}>
          Start Scan
        </button>
      )}
    </div>
  );
  
  // Render fingerprint authentication UI
  const renderFingerprintAuth = () => (
    <div className="fingerprint-auth-container">
      <div className="fingerprint-icon">
        <svg viewBox="0 0 24 24" width="100" height="100">
          <path fill="#4CAF50" d="M17.81 4.47c-.08 0-.16-.02-.23-.06C15.66 3.42 14 3 12.01 3c-1.98 0-3.86.47-5.57 1.41-.24.13-.54.04-.68-.2-.13-.24-.04-.55.2-.68C7.82 2.52 9.86 2 12.01 2c2.13 0 3.99.47 6.03 1.52.25.13.34.43.21.67-.09.18-.26.28-.44.28zM3.5 9.72c-.1 0-.2-.03-.29-.09-.23-.16-.28-.47-.12-.7.99-1.4 2.25-2.5 3.75-3.27C9.98 4.04 14 4.03 17.15 5.65c1.5.77 2.76 1.86 3.75 3.25.16.22.11.54-.12.7-.23.16-.54.11-.7-.12-.9-1.26-2.04-2.25-3.39-2.94-2.87-1.47-6.54-1.47-9.4.01-1.36.7-2.5 1.7-3.4 2.96-.08.14-.23.21-.39.21zm6.25 12.07c-.13 0-.26-.05-.35-.15-.87-.87-1.34-1.43-2.01-2.64-.69-1.23-1.05-2.73-1.05-4.34 0-2.97 2.54-5.39 5.66-5.39s5.66 2.42 5.66 5.39c0 .28-.22.5-.5.5s-.5-.22-.5-.5c0-2.42-2.09-4.39-4.66-4.39-2.57 0-4.66 1.97-4.66 4.39 0 1.44.32 2.77.93 3.85.64 1.15 1.08 1.64 1.85 2.42.19.2.19.51 0 .71-.11.1-.24.15-.37.15zm7.17-1.85c-1.19 0-2.24-.3-3.1-.89-1.49-1.01-2.38-2.65-2.38-4.39 0-.28.22-.5.5-.5s.5.22.5.5c0 1.41.72 2.74 1.94 3.56.71.48 1.54.71 2.54.71.24 0 .64-.03 1.04-.1.27-.05.53.13.58.41.05.27-.13.53-.41.58-.57.11-1.07.12-1.21.12zM14.91 22c-.04 0-.09-.01-.13-.02-1.59-.44-2.63-1.03-3.72-2.1-1.4-1.39-2.17-3.24-2.17-5.22 0-1.62 1.38-2.94 3.08-2.94 1.7 0 3.08 1.32 3.08 2.94 0 1.07.93 1.94 2.08 1.94s2.08-.87 2.08-1.94c0-3.77-3.25-6.83-7.25-6.83-2.84 0-5.44 1.58-6.61 4.03-.39.81-.59 1.76-.59 2.8 0 .78.07 2.01.67 3.61.1.26-.03.55-.29.64-.26.1-.55-.04-.64-.29-.49-1.31-.73-2.61-.73-3.96 0-1.2.23-2.29.68-3.24 1.33-2.79 4.28-4.6 7.51-4.6 4.55 0 8.25 3.51 8.25 7.83 0 1.62-1.38 2.94-3.08 2.94s-3.08-1.32-3.08-2.94c0-1.07-.93-1.94-2.08-1.94s-2.08.87-2.08 1.94c0 1.71.66 3.31 1.87 4.51.95.94 1.86 1.46 3.27 1.85.27.07.42.35.35.61-.05.23-.26.38-.47.38z"/>
        </svg>
      </div>
      <p className="scan-instruction">Place your finger on the fingerprint sensor</p>
      <button className="auth-btn" onClick={authenticateWithFingerprint}>
        Authenticate with Fingerprint
      </button>
    </div>
  );
  
  // Render password authentication UI
  const renderPasswordAuth = () => (
    <div className="password-auth-container">
      <form onSubmit={authenticateWithPassword} className="auth-form">
        <div className="form-group">
          <label htmlFor="username">Username</label>
          <input
            type="text"
            id="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="auth-btn">Sign In</button>
      </form>
    </div>
  );
  
  return (
    <div className="auth-container">
      {isVerified ? (
        <div className="success-container">
          <div className="success-icon">✓</div>
          <h2>Authentication Successful</h2>
          <p>Your identity has been verified and securely stored.</p>
        </div>
      ) : (
        <>
          <div className="auth-header">
            <h2>Secure Authentication</h2>
            <p className="auth-message">{message}</p>
          </div>
          
          {isLoading ? (
            <div className="loading-container">
              <div className="loading-spinner"></div>
              <p>Loading authentication system...</p>
            </div>
          ) : (
            <>
              <div className="auth-methods">
                <button 
                  className={`method-btn ${authMethod === 'face' ? 'active' : ''}`}
                  onClick={() => switchAuthMethod('face')}
                >
                  Face ID
                </button>
                <button 
                  className={`method-btn ${authMethod === 'fingerprint' ? 'active' : ''}`}
                  onClick={() => switchAuthMethod('fingerprint')}
                  disabled={!availableBiometrics.includes('fingerprint')}
                >
                  Fingerprint
                </button>
                <button 
                  className={`method-btn ${authMethod === 'password' ? 'active' : ''}`}
                  onClick={() => switchAuthMethod('password')}
                >
                  Password
                </button>
              </div>
              
              {authMethod === 'face' && renderFaceAuth()}
              {authMethod === 'fingerprint' && renderFingerprintAuth()}
              {authMethod === 'password' && renderPasswordAuth()}
            </>
          )}
        </>
      )}
    </div>
  );
};

export default FaceAuth;
