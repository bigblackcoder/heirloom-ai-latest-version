import os
import cv2
import numpy as np
from flask import Flask, request, jsonify, render_template, Response
from deepface import DeepFace
import base64
import json
import time
from werkzeug.utils import secure_filename

app = Flask(__name__)

# Configuration
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}
REGISTERED_FACES_DIR = 'registered_faces'
VERIFICATION_THRESHOLD = 0.6  # Adjust based on your needs
FACE_MODEL = 'VGG-Face'  # Options: VGG-Face, Facenet, ArcFace

# Ensure directories exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(REGISTERED_FACES_DIR, exist_ok=True)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['POST'])
def register_face():
    """Register a new face"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    user_id = request.form.get('user_id')
    
    if not user_id:
        return jsonify({'error': 'User ID is required'}), 400
    
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    
    if file and allowed_file(file.filename):
        # Save the uploaded file
        filename = secure_filename(f"{user_id}.jpg")
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        # Detect face in the image
        try:
            face_objs = DeepFace.extract_faces(img_path=filepath)
            if len(face_objs) == 0:
                return jsonify({'error': 'No face detected in the image'}), 400
            
            # Save the face image for future verification
            registered_face_path = os.path.join(REGISTERED_FACES_DIR, f"{user_id}.jpg")
            os.rename(filepath, registered_face_path)
            
            return jsonify({
                'success': True,
                'message': 'Face registered successfully',
                'user_id': user_id
            })
        except Exception as e:
            return jsonify({'error': f'Face detection failed: {str(e)}'}), 500
    
    return jsonify({'error': 'Invalid file format'}), 400

@app.route('/verify', methods=['POST'])
def verify_face():
    """Verify a face against registered faces"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    user_id = request.form.get('user_id')
    
    if not user_id:
        return jsonify({'error': 'User ID is required'}), 400
    
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    
    if file and allowed_file(file.filename):
        # Save the uploaded file
        filename = secure_filename(f"verify_{user_id}.jpg")
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        # Check if user is registered
        registered_face_path = os.path.join(REGISTERED_FACES_DIR, f"{user_id}.jpg")
        if not os.path.exists(registered_face_path):
            return jsonify({'error': 'User not registered'}), 404
        
        # Verify face
        try:
            result = DeepFace.verify(
                img1_path=filepath,
                img2_path=registered_face_path,
                model_name=FACE_MODEL
            )
            
            # Clean up verification image
            os.remove(filepath)
            
            return jsonify({
                'success': True,
                'verified': result['verified'],
                'distance': result['distance'],
                'threshold': result['threshold'],
                'model': result['model']
            })
        except Exception as e:
            return jsonify({'error': f'Face verification failed: {str(e)}'}), 500
    
    return jsonify({'error': 'Invalid file format'}), 400

@app.route('/verify_stream', methods=['POST'])
def verify_stream():
    """Verify a face from a base64 encoded image stream"""
    data = request.json
    
    if not data or 'image' not in data or 'user_id' not in data:
        return jsonify({'error': 'Missing image data or user ID'}), 400
    
    user_id = data['user_id']
    image_b64 = data['image'].split(',')[1] if ',' in data['image'] else data['image']
    
    # Check if user is registered
    registered_face_path = os.path.join(REGISTERED_FACES_DIR, f"{user_id}.jpg")
    if not os.path.exists(registered_face_path):
        return jsonify({'error': 'User not registered'}), 404
    
    try:
        # Decode base64 image
        image_data = base64.b64decode(image_b64)
        nparr = np.frombuffer(image_data, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        # Save temporary image
        temp_path = os.path.join(app.config['UPLOAD_FOLDER'], f"stream_{user_id}.jpg")
        cv2.imwrite(temp_path, img)
        
        # Verify face
        result = DeepFace.verify(
            img1_path=temp_path,
            img2_path=registered_face_path,
            model_name=FACE_MODEL
        )
        
        # Clean up temporary image
        os.remove(temp_path)
        
        return jsonify({
            'success': True,
            'verified': result['verified'],
            'distance': result['distance'],
            'threshold': result['threshold'],
            'model': result['model']
        })
    except Exception as e:
        return jsonify({'error': f'Face verification failed: {str(e)}'}), 500

@app.route('/verify_native', methods=['POST'])
def verify_native():
    """Handle verification from native biometric systems (Apple FaceID/Google)"""
    data = request.json
    
    if not data or 'user_id' not in data or 'platform' not in data or 'auth_token' not in data:
        return jsonify({'error': 'Missing required data'}), 400
    
    user_id = data['user_id']
    platform = data['platform']
    auth_token = data['auth_token']
    
    # In a real implementation, you would verify the auth_token with Apple/Google
    # This is a simplified mock implementation
    
    # Mock verification (in production, you'd validate with Apple/Google servers)
    if platform == 'apple' and auth_token:
        # Mock Apple FaceID verification
        return jsonify({
            'success': True,
            'verified': True,
            'method': 'Apple FaceID',
            'user_id': user_id
        })
    elif platform == 'google' and auth_token:
        # Mock Google biometric verification
        return jsonify({
            'success': True,
            'verified': True,
            'method': 'Google Biometric',
            'user_id': user_id
        })
    else:
        return jsonify({'error': 'Invalid platform or auth token'}), 400

@app.route('/users', methods=['GET'])
def list_users():
    """List all registered users"""
    users = []
    for filename in os.listdir(REGISTERED_FACES_DIR):
        if filename.endswith('.jpg'):
            user_id = filename.split('.')[0]
            users.append(user_id)
    
    return jsonify({
        'success': True,
        'users': users
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=True)
