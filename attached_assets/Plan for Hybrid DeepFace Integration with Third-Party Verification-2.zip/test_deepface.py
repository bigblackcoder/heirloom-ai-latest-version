import os
import cv2
from deepface import DeepFace

def test_face_verification():
    """
    Test DeepFace's face verification functionality by comparing two images.
    """
    print("Starting DeepFace verification test...")
    
    # Create test directory if it doesn't exist
    test_dir = os.path.join(os.getcwd(), "test_images")
    os.makedirs(test_dir, exist_ok=True)
    
    # Download sample images for testing
    print("Downloading sample images...")
    import urllib.request
    
    # Sample images from public domain
    img1_url = "https://github.com/serengil/deepface/raw/master/tests/dataset/img1.jpg"
    img2_url = "https://github.com/serengil/deepface/raw/master/tests/dataset/img2.jpg"
    
    test_img1_path = os.path.join(test_dir, "test1.jpg")
    test_img2_path = os.path.join(test_dir, "test2.jpg")
    
    try:
        urllib.request.urlretrieve(img1_url, test_img1_path)
        urllib.request.urlretrieve(img2_url, test_img2_path)
        print(f"Sample images downloaded to {test_dir}")
    except Exception as e:
        print(f"Error downloading images: {e}")
        return
    
    # Verify the images exist
    if not os.path.isfile(test_img1_path) or not os.path.isfile(test_img2_path):
        print("Error: Test images not found")
        return
    
    # Display the images
    img1 = cv2.imread(test_img1_path)
    img2 = cv2.imread(test_img2_path)
    
    if img1 is None or img2 is None:
        print("Error: Could not read test images")
        return
    
    print("Test images loaded successfully")
    print(f"Image 1 shape: {img1.shape}")
    print(f"Image 2 shape: {img2.shape}")
    
    # Run face verification
    print("\nRunning face verification...")
    try:
        # Basic verification
        result = DeepFace.verify(img1_path=test_img1_path, img2_path=test_img2_path)
        print("\nVerification Result:")
        print(f"Verified: {result['verified']}")
        print(f"Distance: {result['distance']}")
        print(f"Threshold: {result['threshold']}")
        print(f"Model: {result['model']}")
        print(f"Detector Backend: {result['detector_backend']}")
        
        # Try different models
        print("\nTesting with different models:")
        models = ["VGG-Face", "Facenet", "OpenFace", "DeepFace", "ArcFace"]
        
        for model in models:
            try:
                print(f"\nTesting model: {model}")
                result = DeepFace.verify(img1_path=test_img1_path, img2_path=test_img2_path, model_name=model)
                print(f"Verified: {result['verified']}")
                print(f"Distance: {result['distance']}")
                print(f"Threshold: {result['threshold']}")
            except Exception as e:
                print(f"Error with model {model}: {e}")
        
        # Face detection test
        print("\nRunning face detection...")
        face_analysis = DeepFace.extract_faces(img_path=test_img1_path)
        print(f"Detected {len(face_analysis)} faces")
        
        # Face analysis test
        print("\nRunning face analysis...")
        analysis = DeepFace.analyze(img_path=test_img1_path, actions=['age', 'gender', 'emotion', 'race'])
        print("Analysis Results:")
        print(f"Age: {analysis[0]['age']}")
        print(f"Gender: {analysis[0]['gender']}")
        print(f"Dominant emotion: {analysis[0]['dominant_emotion']}")
        print(f"Dominant race: {analysis[0]['dominant_race']}")
        
        print("\nDeepFace test completed successfully!")
        return True
        
    except Exception as e:
        print(f"Error during face verification: {e}")
        return False

if __name__ == "__main__":
    test_face_verification()
