import { useState, useEffect } from 'react';
import FaceAuth from './components/FaceAuth';
import BlockchainOnboarding from './components/BlockchainOnboarding';
import { identityContractService } from './blockchain/IdentityContract';
import './App.css';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);
  const [blockchainStatus, setBlockchainStatus] = useState<'connecting' | 'connected' | 'error' | 'simulation'>('connecting');
  const [verificationHistory, setVerificationHistory] = useState<{methods: string[], timestamps: number[]} | null>(null);
  const [userAddress, setUserAddress] = useState<string | null>(null);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [simulationMode, setSimulationMode] = useState(false);

  // Initialize blockchain connection
  useEffect(() => {
    const initBlockchain = async () => {
      try {
        // Check if MetaMask is available
        if (window.ethereum) {
          // Check if we should show onboarding
          const accounts = await window.ethereum.request({ method: 'eth_accounts' });
          if (accounts.length === 0) {
            // No accounts connected, show onboarding
            setShowOnboarding(true);
            setBlockchainStatus('connecting');
          } else {
            // Already connected, check network
            const chainId = await window.ethereum.request({ method: 'eth_chainId' });
            if (chainId !== '0x13881') { // Not on Mumbai Testnet
              setShowOnboarding(true);
              setBlockchainStatus('connecting');
            } else {
              // Connected and on correct network
              const connected = await identityContractService.initializeProvider();
              if (connected) {
                setBlockchainStatus('connected');
                const address = await identityContractService.getUserAddress();
                setUserAddress(address);
              } else {
                setShowOnboarding(true);
                setBlockchainStatus('error');
              }
            }
          }
        } else {
          // No MetaMask, show onboarding
          setShowOnboarding(true);
          setBlockchainStatus('error');
        }
      } catch (error) {
        console.error('Error initializing blockchain:', error);
        setShowOnboarding(true);
        setBlockchainStatus('error');
      }
    };

    initBlockchain();
  }, []);

  // Handle successful authentication
  const handleAuthSuccess = async (id: string) => {
    setUserId(id);
    setIsAuthenticated(true);
    
    // Store verification on blockchain or simulate
    try {
      if (simulationMode) {
        console.log('Simulation: Verification stored on blockchain');
        // Simulate verification history
        setVerificationHistory({
          methods: ['face', 'password'],
          timestamps: [Math.floor(Date.now() / 1000), Math.floor(Date.now() / 1000) - 86400]
        });
      } else {
        const txHash = await identityContractService.storeVerification('face');
        console.log('Verification stored on blockchain:', txHash);
        
        // Get verification history
        const history = await identityContractService.getVerificationHistory();
        setVerificationHistory(history);
      }
    } catch (error) {
      console.error('Error interacting with blockchain:', error);
      // Fallback to simulation if blockchain interaction fails
      setSimulationMode(true);
      setBlockchainStatus('simulation');
      setVerificationHistory({
        methods: ['face'],
        timestamps: [Math.floor(Date.now() / 1000)]
      });
    }
  };

  // Handle authentication failure
  const handleAuthFailure = (error: string) => {
    console.error('Authentication failed:', error);
    setIsAuthenticated(false);
    setUserId(null);
  };

  // Handle onboarding completion
  const handleOnboardingComplete = async () => {
    setShowOnboarding(false);
    setSimulationMode(false);
    
    // Initialize blockchain connection
    const connected = await identityContractService.initializeProvider();
    if (connected) {
      setBlockchainStatus('connected');
      const address = await identityContractService.getUserAddress();
      setUserAddress(address);
    } else {
      setBlockchainStatus('error');
    }
  };

  // Handle onboarding skip (simulation mode)
  const handleOnboardingSkip = () => {
    setShowOnboarding(false);
    setSimulationMode(true);
    setBlockchainStatus('simulation');
  };

  // Render verification history
  const renderVerificationHistory = () => {
    if (!verificationHistory || verificationHistory.methods.length === 0) {
      return <p>No verification history found.</p>;
    }

    return (
      <div className="history-container">
        <h3>Verification History</h3>
        <ul className="history-list">
          {verificationHistory.methods.map((method, index) => (
            <li key={index} className="history-item">
              <span className="method">{method}</span>
              <span className="timestamp">
                {new Date(verificationHistory.timestamps[index] * 1000).toLocaleString()}
              </span>
            </li>
          ))}
        </ul>
      </div>
    );
  };

  // Render blockchain status indicator
  const renderBlockchainStatus = () => {
    switch (blockchainStatus) {
      case 'connecting':
        return (
          <div className="blockchain-status connecting">
            Connecting to Polygon Testnet...
            <button 
              className="setup-btn"
              onClick={() => setShowOnboarding(true)}
            >
              Setup Blockchain Connection
            </button>
          </div>
        );
      
      case 'error':
        return (
          <div className="blockchain-status error">
            Error connecting to blockchain
            <button 
              className="setup-btn"
              onClick={() => setShowOnboarding(true)}
            >
              Setup Blockchain Connection
            </button>
          </div>
        );
      
      case 'connected':
        return (
          <div className="blockchain-status connected">
            Connected to Polygon Testnet
            {userAddress && <div className="user-address">Address: {userAddress}</div>}
          </div>
        );
      
      case 'simulation':
        return (
          <div className="blockchain-status simulation">
            Running in Simulation Mode
            <button 
              className="setup-btn"
              onClick={() => setShowOnboarding(true)}
            >
              Setup Real Blockchain Connection
            </button>
          </div>
        );
      
      default:
        return null;
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>Secure Identity Verification</h1>
        <p className="subtitle">Hybrid Biometric Authentication with Blockchain Storage</p>
        
        {renderBlockchainStatus()}
      </header>
      
      <main className="App-main">
        {showOnboarding ? (
          <BlockchainOnboarding
            onComplete={handleOnboardingComplete}
            onSkip={handleOnboardingSkip}
          />
        ) : !isAuthenticated ? (
          <FaceAuth 
            onAuthSuccess={handleAuthSuccess} 
            onAuthFailure={handleAuthFailure} 
          />
        ) : (
          <div className="authenticated-container">
            <div className="success-message">
              <h2>Authentication Successful</h2>
              <p>
                Your identity has been verified and {simulationMode ? 'simulated as' : 'securely stored on'} the Polygon blockchain.
              </p>
              <p>User ID: {userId}</p>
            </div>
            
            {renderVerificationHistory()}
            
            <div className="actions">
              <button 
                className="logout-btn"
                onClick={() => setIsAuthenticated(false)}
              >
                Log Out
              </button>
            </div>
          </div>
        )}
      </main>
      
      <footer className="App-footer">
        <p>Secure Identity Verification System &copy; 2025</p>
      </footer>
    </div>
  );
}

export default App;
